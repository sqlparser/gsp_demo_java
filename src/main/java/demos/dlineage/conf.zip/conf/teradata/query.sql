select t.RequestText as sourceCode,
    case 
    when t.TableKind='V' Then 'view'
    when t.TableKind='P' Then 'procedure'
    when t.TableKind='E' Then 'procedure'
    when t.TableKind='G' Then 'trigger'
    when t.TableKind='M' Then 'macro'
    when t.TableKind='A' Then 'function'
    when t.TableKind='B' Then 'function'
    when t.TableKind='C' Then 'function'
    when t.TableKind='L' Then 'function'
    when t.TableKind='R' Then 'function'
    when t.TableKind='S' Then 'function'
    when t.TableKind='F' Then 'function'
    else t.TableKind END as dbOjbType,
    '"' || TRIM(t.TableName) || '"' as dbObjName,
    null as groupName,
    '"' || TRIM(t.DatabaseName) || '"' as databaseName,
    '"' || TRIM(t.DatabaseName) || '"'  as schemaName
from DBC.Tables t where t.DatabaseName='%s' and t.TableKind not in ('T', 'U', 'X') and t.RequestText is not null and dbOjbType in ('view','procedure','trigger','macro','function');